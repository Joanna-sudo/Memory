package com.example.memory;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class NewGame extends AppCompatActivity {
    DB baza;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.new_game);
    }

    public void IdiNaMainActivity(View view) {
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }

    public void IdiNaGame(View view) {
        baza = new DB(this);

        EditText editText = findViewById(R.id.et);
        String tekst = editText.getText().toString();
        if (tekst.length() <= 25) {
            baza.dodajIgraca(tekst, 1, 0);

            Intent intent = new Intent(this, Game.class);
            intent.putExtra("nivo", "1");
            intent.putExtra("ime", tekst);
            startActivity(intent);
        } else {
            Toast.makeText(this, "The name is too long. Use max 25  characters. :)", Toast.LENGTH_LONG).show();
        }
    }

}

package com.example.memory;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;

public class LvlCompleted extends AppCompatActivity {
    DB baza;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.lvl_comleted);
    }

    public void sledeciNivo(View view) {
        Bundle extras = getIntent().getExtras();
        String ime;
        String nivo;
        if (extras != null) {
            nivo = extras.getString("nivo");
            ime = extras.getString("ime");

            baza = new DB(this);
            baza.povecajPoene(ime);

            Intent intent = new Intent(view.getContext(), Game.class);
            intent.putExtra("ime", ime);
            intent.putExtra("nivo", nivo);
            startActivity(intent);
        }

    }

}

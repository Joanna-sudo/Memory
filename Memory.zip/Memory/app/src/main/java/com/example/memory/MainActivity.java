package com.example.memory;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity{
    DB baza;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void IdiNaNewGame(View view) {
        Intent intent = new Intent(this, NewGame.class);
        startActivity(intent);
    }

    public void IdiNaWhoThis(View view) {
        baza = new DB(this);
        String upit = "SELECT * FROM igraci";
        Cursor kursor = baza.sadrzaj();

        if (kursor.moveToFirst()) {
            Intent intent = new Intent(this, WhoThis.class);
            startActivity(intent);
        } else {
            Toast.makeText(this, "There are no saved games :)", Toast.LENGTH_LONG).show();
        }
    }

}

package com.example.memory;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;

public class KrajIgre extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.kraj_igrice);
    }

    public void idiNaPocetak(View view) {
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }
}

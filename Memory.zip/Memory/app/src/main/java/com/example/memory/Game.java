package com.example.memory;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.ImageView;
import java.util.Arrays;
import java.util.Collections;

public class Game extends AppCompatActivity {

    DB baza;
    String nivo;
    int nivoInt;
    String ime;
    ImageView karta1, karta2, karta3, karta4, karta5, karta6, karta7, karta8, karta9, karta10, karta11, karta12, karta13, karta14, karta15, karta16, karta17, karta18,
            karta19, karta20, karta21, karta22, karta23, karta24, karta25, karta26, karta27, karta28, karta29, karta30, karta31, karta32, karta33, karta34, karta35, karta36;

    //prvi nivo je 2x2
    Integer[] nizKartica2x2 = {11, 21, 12, 22};
    //drugi nivo je 4x4
    Integer[] nizKartica4x4 = {11, 21, 31, 41, 51, 61, 71, 81, 12, 22, 32, 42, 52, 62, 72, 82};
    //treci i poslednji nivo je 6x6
    Integer[] nizKartica6x6 = {11, 21, 31, 41, 51, 61, 71, 81, 91, 101, 111, 121, 131, 141, 151, 161, 171, 181, 12, 22, 32, 42, 52, 62, 72, 82, 92, 102, 112, 122, 132, 142, 152, 162, 172, 182};

    int slika11, slika21, slika31, slika41, slika51, slika61, slika71, slika81, slika91, slika101, slika111, slika121, slika131, slika141, slika151, slika161, slika171, slika181,
            slika12, slika22, slika32, slika42, slika52, slika62, slika72, slika82, slika92, slika102, slika112, slika122, slika132, slika142, slika152, slika162, slika172, slika182;
    int prvaKartica, drugaKartica;
    int kliknutoPrvo, kliknutoDrugo;
    int brOkrenutihKarata = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            nivo = extras.getString("nivo");
        }

        if (nivo.equals("1")) {
            setContentView(R.layout.gamelvl1);
            ucitajKartice2x2();
            ucitajSlike2x2();
            //mesamo kartice
            Collections.shuffle(Arrays.asList(nizKartica2x2));
        } else if (nivo.equals("2")) {
            setContentView(R.layout.gamelvl2);
            ucitajKartice4x4();
            ucitajSlike4x4();
            //mesamo kartice
            Collections.shuffle(Arrays.asList(nizKartica4x4));
        } else if (nivo.equals("3")) {
            setContentView(R.layout.gamelvl3);
            ucitajKartice6x6();
            ucitajSlike6x6();
            //mesamo kartice
            Collections.shuffle(Arrays.asList(nizKartica6x6));
        } else {
            //kraj igre predjeni su svi nivoi
            krajIgrice();
        }

    }

    void ucitajKartice2x2() {
        karta1 = findViewById(R.id.kartica1);
        karta2 = findViewById(R.id.kartica2);
        karta3 = findViewById(R.id.kartica3);
        karta4 = findViewById(R.id.kartica4);

        karta1.setTag("0");
        karta2.setTag("1");
        karta3.setTag("2");
        karta4.setTag("3");
    }

    void ucitajKartice4x4() {
        karta1 = findViewById(R.id.kartica1);
        karta2 = findViewById(R.id.kartica2);
        karta3 = findViewById(R.id.kartica3);
        karta4 = findViewById(R.id.kartica4);
        karta5= findViewById(R.id.kartica5);
        karta6 = findViewById(R.id.kartica6);
        karta7 = findViewById(R.id.kartica7);
        karta8 = findViewById(R.id.kartica8);
        karta9 = findViewById(R.id.kartica9);
        karta10 = findViewById(R.id.kartica10);
        karta11 = findViewById(R.id.kartica11);
        karta12 = findViewById(R.id.kartica12);
        karta13 = findViewById(R.id.kartica13);
        karta14 = findViewById(R.id.kartica14);
        karta15 = findViewById(R.id.kartica15);
        karta16 = findViewById(R.id.kartica16);

        karta1.setTag("0");
        karta2.setTag("1");
        karta3.setTag("2");
        karta4.setTag("3");
        karta5.setTag("4");
        karta6.setTag("5");
        karta7.setTag("6");
        karta8.setTag("7");
        karta9.setTag("8");
        karta10.setTag("9");
        karta11.setTag("10");
        karta12.setTag("11");
        karta13.setTag("12");
        karta14.setTag("13");
        karta15.setTag("14");
        karta16.setTag("15");
    }

    void ucitajKartice6x6() {
        karta1 = findViewById(R.id.kartica1);
        karta2 = findViewById(R.id.kartica2);
        karta3 = findViewById(R.id.kartica3);
        karta4 = findViewById(R.id.kartica4);
        karta5= findViewById(R.id.kartica5);
        karta6 = findViewById(R.id.kartica6);
        karta7 = findViewById(R.id.kartica7);
        karta8 = findViewById(R.id.kartica8);
        karta9 = findViewById(R.id.kartica9);
        karta10 = findViewById(R.id.kartica10);
        karta11 = findViewById(R.id.kartica11);
        karta12 = findViewById(R.id.kartica12);
        karta13 = findViewById(R.id.kartica13);
        karta14 = findViewById(R.id.kartica14);
        karta15 = findViewById(R.id.kartica15);
        karta16 = findViewById(R.id.kartica16);
        karta17 = findViewById(R.id.kartica17);
        karta18 = findViewById(R.id.kartica18);
        karta19 = findViewById(R.id.kartica19);
        karta20 = findViewById(R.id.kartica20);
        karta21 = findViewById(R.id.kartica21);
        karta22 = findViewById(R.id.kartica22);
        karta23 = findViewById(R.id.kartica23);
        karta24 = findViewById(R.id.kartica24);
        karta25 = findViewById(R.id.kartica25);
        karta26 = findViewById(R.id.kartica26);
        karta27 = findViewById(R.id.kartica27);
        karta28 = findViewById(R.id.kartica28);
        karta29 = findViewById(R.id.kartica29);
        karta30 = findViewById(R.id.kartica30);
        karta31 = findViewById(R.id.kartica31);
        karta32 = findViewById(R.id.kartica32);
        karta33 = findViewById(R.id.kartica33);
        karta34 = findViewById(R.id.kartica34);
        karta35 = findViewById(R.id.kartica35);
        karta36 = findViewById(R.id.kartica36);

        karta1.setTag("0");
        karta2.setTag("1");
        karta3.setTag("2");
        karta4.setTag("3");
        karta5.setTag("4");
        karta6.setTag("5");
        karta7.setTag("6");
        karta8.setTag("7");
        karta9.setTag("8");
        karta10.setTag("9");
        karta11.setTag("10");
        karta12.setTag("11");
        karta13.setTag("12");
        karta14.setTag("13");
        karta15.setTag("14");
        karta16.setTag("15");
        karta17.setTag("16");
        karta18.setTag("17");
        karta19.setTag("18");
        karta20.setTag("19");
        karta21.setTag("20");
        karta22.setTag("21");
        karta23.setTag("22");
        karta24.setTag("23");
        karta25.setTag("24");
        karta26.setTag("25");
        karta27.setTag("26");
        karta28.setTag("27");
        karta29.setTag("28");
        karta30.setTag("29");
        karta31.setTag("30");
        karta32.setTag("31");
        karta33.setTag("32");
        karta34.setTag("33");
        karta35.setTag("34");
        karta36.setTag("35");
    }

    void ucitajSlike2x2() {
        slika11 = R.drawable.slika11;
        slika21 = R.drawable.slika21;
        slika12 = R.drawable.slika12;
        slika22 = R.drawable.slika22;
    }

    void ucitajSlike4x4() {
        slika11 = R.drawable.slika11;
        slika21 = R.drawable.slika21;
        slika31 = R.drawable.slika31;
        slika41 = R.drawable.slika41;
        slika51 = R.drawable.slika51;
        slika61 = R.drawable.slika61;
        slika71 = R.drawable.slika71;
        slika81 = R.drawable.slika81;

        slika12 = R.drawable.slika12;
        slika22 = R.drawable.slika22;
        slika32 = R.drawable.slika32;
        slika42 = R.drawable.slika42;
        slika52 = R.drawable.slika52;
        slika62 = R.drawable.slika62;
        slika72 = R.drawable.slika72;
        slika82 = R.drawable.slika82;
    }

    void ucitajSlike6x6() {
        slika11 = R.drawable.slika11;
        slika21 = R.drawable.slika21;
        slika31 = R.drawable.slika31;
        slika41 = R.drawable.slika41;
        slika51 = R.drawable.slika51;
        slika61 = R.drawable.slika61;
        slika71 = R.drawable.slika71;
        slika81 = R.drawable.slika81;
        slika91 = R.drawable.slika91;
        slika101 = R.drawable.slika101;
        slika111 = R.drawable.slika111;
        slika121 = R.drawable.slika121;
        slika131 = R.drawable.slika131;
        slika141 = R.drawable.slika141;
        slika151 = R.drawable.slika151;
        slika161 = R.drawable.slika161;
        slika171 = R.drawable.slika171;
        slika181 = R.drawable.slika181;

        slika12 = R.drawable.slika12;
        slika22 = R.drawable.slika22;
        slika32 = R.drawable.slika32;
        slika42 = R.drawable.slika42;
        slika52 = R.drawable.slika52;
        slika62 = R.drawable.slika62;
        slika72 = R.drawable.slika72;
        slika82 = R.drawable.slika82;
        slika92 = R.drawable.slika92;
        slika102 = R.drawable.slika102;
        slika112 = R.drawable.slika112;
        slika122 = R.drawable.slika122;
        slika132 = R.drawable.slika132;
        slika142 = R.drawable.slika142;
        slika152 = R.drawable.slika152;
        slika162 = R.drawable.slika162;
        slika172 = R.drawable.slika172;
        slika182 = R.drawable.slika182;
    }

    public void okreniKarticu (View view) {
        int redniBr = Integer.parseInt((String) view.getTag());
        okreni((ImageView) view, redniBr);
    }

    public void okreni(ImageView view, int redniBr) {
        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            nivo = extras.getString("nivo");
        }

        if (nivo.equals("1")) {
            if (nizKartica2x2[redniBr] == 11) {
                view.setImageResource(slika11);
            } else if (nizKartica2x2[redniBr] == 12) {
                view.setImageResource(slika12);
            }  else if (nizKartica2x2[redniBr] == 21) {
                view.setImageResource(slika21);
            }  else if (nizKartica2x2[redniBr] == 22) {
                view.setImageResource(slika22);
            }

            if (brOkrenutihKarata == 1) {
                prvaKartica = nizKartica2x2[redniBr];

                if (prvaKartica == 12) {
                    prvaKartica = 11;
                } else if (prvaKartica == 22) {
                    prvaKartica = 21;
                }

                kliknutoPrvo = redniBr;
                brOkrenutihKarata = 2;
                view.setEnabled(false);
            } else if (brOkrenutihKarata == 2) {
                drugaKartica = nizKartica2x2[redniBr];

                if (drugaKartica == 12) {
                    drugaKartica = 11;
                } else if (drugaKartica == 22) {
                    drugaKartica = 21;
                }

                kliknutoDrugo = redniBr;
                brOkrenutihKarata = 1;
                karta1.setEnabled(false);
                karta2.setEnabled(false);
                karta3.setEnabled(false);
                karta4.setEnabled(false);

                Handler handler = new Handler();
                handler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        daLiSuIsteKarte1();
                    }
                }, 1000);
            }
        } else if (nivo.equals("2")) {
            if (nizKartica4x4[redniBr] == 11) {
                view.setImageResource(slika11);
            } else if (nizKartica4x4[redniBr] == 21) {
                view.setImageResource(slika21);
            } else if (nizKartica4x4[redniBr] == 31) {
                view.setImageResource(slika31);
            } else if (nizKartica4x4[redniBr] == 41) {
                view.setImageResource(slika41);
            } else if (nizKartica4x4[redniBr] == 51) {
                view.setImageResource(slika51);
            }  else if (nizKartica4x4[redniBr] == 61) {
                view.setImageResource(slika61);
            }  else if (nizKartica4x4[redniBr] == 71) {
                view.setImageResource(slika71);
            } else if (nizKartica4x4[redniBr] == 81) {
                view.setImageResource(slika81);
            } else if (nizKartica4x4[redniBr] == 12) {
                view.setImageResource(slika12);
            }  else if (nizKartica4x4[redniBr] == 22) {
                view.setImageResource(slika22);
            }  else if (nizKartica4x4[redniBr] == 32) {
                view.setImageResource(slika32);
            } else if (nizKartica4x4[redniBr] == 42) {
                view.setImageResource(slika42);
            }  else if (nizKartica4x4[redniBr] == 52) {
                view.setImageResource(slika52);
            }  else if (nizKartica4x4[redniBr] == 62) {
                view.setImageResource(slika62);
            } else if (nizKartica4x4[redniBr] == 72) {
                view.setImageResource(slika72);
            } else if (nizKartica4x4[redniBr] == 82) {
                view.setImageResource(slika82);
            }

            if (brOkrenutihKarata == 1) {
                prvaKartica = nizKartica4x4[redniBr];

                if (prvaKartica == 12) {
                    prvaKartica = 11;
                } else if (prvaKartica == 22) {
                    prvaKartica = 21;
                }   else if (prvaKartica == 32) {
                    prvaKartica = 31;
                }  else if (prvaKartica == 42) {
                    prvaKartica = 41;
                }  else if (prvaKartica == 52) {
                    prvaKartica = 51;
                }  else if (prvaKartica == 62) {
                    prvaKartica = 61;
                }  else if (prvaKartica == 72) {
                    prvaKartica = 71;
                }  else if (prvaKartica == 82) {
                    prvaKartica = 81;
                }

                kliknutoPrvo = redniBr;
                brOkrenutihKarata = 2;
                view.setEnabled(false);
            } else if (brOkrenutihKarata == 2) {
                drugaKartica = nizKartica4x4[redniBr];

                if (drugaKartica == 12) {
                    drugaKartica = 11;
                } else if (drugaKartica == 22) {
                    drugaKartica = 21;
                }   else if (drugaKartica == 32) {
                    drugaKartica = 31;
                }  else if (drugaKartica == 42) {
                    drugaKartica = 41;
                }  else if (drugaKartica == 52) {
                    drugaKartica = 51;
                }  else if (drugaKartica == 62) {
                    drugaKartica = 61;
                }  else if (drugaKartica == 72) {
                    drugaKartica = 71;
                }  else if (drugaKartica == 82) {
                    drugaKartica = 81;
                }

                kliknutoDrugo = redniBr;
                brOkrenutihKarata = 1;
                karta1.setEnabled(false);
                karta2.setEnabled(false);
                karta3.setEnabled(false);
                karta4.setEnabled(false);
                karta5.setEnabled(false);
                karta6.setEnabled(false);
                karta7.setEnabled(false);
                karta8.setEnabled(false);
                karta9.setEnabled(false);
                karta10.setEnabled(false);
                karta11.setEnabled(false);
                karta12.setEnabled(false);
                karta13.setEnabled(false);
                karta14.setEnabled(false);
                karta15.setEnabled(false);
                karta16.setEnabled(false);

                Handler handler = new Handler();
                handler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        daLiSuIsteKarte2();
                    }
                }, 1000);
            }
        } else if (nivo.equals("3")) {
            if (nizKartica6x6[redniBr] == 11) {
                view.setImageResource(slika11);
            } else if (nizKartica6x6[redniBr] == 21) {
                view.setImageResource(slika21);
            } else if (nizKartica6x6[redniBr] == 31) {
                view.setImageResource(slika31);
            } else if (nizKartica6x6[redniBr] == 41) {
                view.setImageResource(slika41);
            } else if (nizKartica6x6[redniBr] == 51) {
                view.setImageResource(slika51);
            }  else if (nizKartica6x6[redniBr] == 61) {
                view.setImageResource(slika61);
            }  else if (nizKartica6x6[redniBr] == 71) {
                view.setImageResource(slika71);
            } else if (nizKartica6x6[redniBr] == 81) {
                view.setImageResource(slika81);
            }  else if (nizKartica6x6[redniBr] == 91) {
                view.setImageResource(slika91);
            }  else if (nizKartica6x6[redniBr] == 101) {
                view.setImageResource(slika101);
            } else if (nizKartica6x6[redniBr] == 111) {
                view.setImageResource(slika111);
            } else if (nizKartica6x6[redniBr] == 121) {
                view.setImageResource(slika121);
            } else if (nizKartica6x6[redniBr] == 131) {
                view.setImageResource(slika131);
            } else if (nizKartica6x6[redniBr] == 141) {
                view.setImageResource(slika141);
            } else if (nizKartica6x6[redniBr] == 151) {
                view.setImageResource(slika151);
            } else if (nizKartica6x6[redniBr] == 161) {
                view.setImageResource(slika161);
            } else if (nizKartica6x6[redniBr] == 171) {
                view.setImageResource(slika171);
            }  else if (nizKartica6x6[redniBr] == 181) {
                view.setImageResource(slika181);
            }  else if (nizKartica6x6[redniBr] == 12) {
                view.setImageResource(slika12);
            }  else if (nizKartica6x6[redniBr] == 22) {
                view.setImageResource(slika22);
            }  else if (nizKartica6x6[redniBr] == 32) {
                view.setImageResource(slika32);
            } else if (nizKartica6x6[redniBr] == 42) {
                view.setImageResource(slika42);
            }  else if (nizKartica6x6[redniBr] == 52) {
                view.setImageResource(slika52);
            }  else if (nizKartica6x6[redniBr] == 62) {
                view.setImageResource(slika62);
            } else if (nizKartica6x6[redniBr] == 72) {
                view.setImageResource(slika72);
            } else if (nizKartica6x6[redniBr] == 82) {
                view.setImageResource(slika82);
            } else if (nizKartica6x6[redniBr] == 92) {
                view.setImageResource(slika92);
            } else if (nizKartica6x6[redniBr] == 102) {
                view.setImageResource(slika102);
            } else if (nizKartica6x6[redniBr] == 112) {
                view.setImageResource(slika112);
            } else if (nizKartica6x6[redniBr] == 122) {
                view.setImageResource(slika122);
            } else if (nizKartica6x6[redniBr] == 132) {
                view.setImageResource(slika132);
            }  else if (nizKartica6x6[redniBr] == 142) {
                view.setImageResource(slika142);
            }  else if (nizKartica6x6[redniBr] == 152) {
                view.setImageResource(slika152);
            } else if (nizKartica6x6[redniBr] == 162) {
                view.setImageResource(slika162);
            } else if (nizKartica6x6[redniBr] == 172) {
                view.setImageResource(slika172);
            } else if (nizKartica6x6[redniBr] == 182) {
                view.setImageResource(slika182);
            }

            if (brOkrenutihKarata == 1) {
                prvaKartica = nizKartica6x6[redniBr];

                if (prvaKartica == 12) {
                    prvaKartica = 11;
                } else if (prvaKartica == 22) {
                    prvaKartica = 21;
                } else if (prvaKartica == 32) {
                    prvaKartica = 31;
                } else if (prvaKartica == 42) {
                    prvaKartica = 41;
                } else if (prvaKartica == 52) {
                    prvaKartica = 51;
                } else if (prvaKartica == 62) {
                    prvaKartica = 61;
                } else if (prvaKartica == 72) {
                    prvaKartica = 71;
                } else if (prvaKartica == 82) {
                    prvaKartica = 81;
                } else if (prvaKartica == 92) {
                    prvaKartica = 91;
                } else if (prvaKartica == 102) {
                    prvaKartica = 101;
                } else if (prvaKartica == 112) {
                    prvaKartica = 111;
                } else if (prvaKartica == 122) {
                    prvaKartica = 121;
                } else if (prvaKartica == 132) {
                    prvaKartica = 131;
                } else if (prvaKartica == 142) {
                    prvaKartica = 141;
                } else if (prvaKartica == 152) {
                    prvaKartica = 151;
                } else if (prvaKartica == 162) {
                    prvaKartica = 161;
                } else if (prvaKartica == 172) {
                    prvaKartica = 171;
                } else if (prvaKartica == 182) {
                    prvaKartica = 181;
                }

                kliknutoPrvo = redniBr;
                brOkrenutihKarata = 2;
                view.setEnabled(false);
            } else if (brOkrenutihKarata == 2) {
                drugaKartica = nizKartica6x6[redniBr];

                if (drugaKartica == 12) {
                    drugaKartica = 11;
                } else if (drugaKartica == 22) {
                    drugaKartica = 21;
                } else if (drugaKartica == 32) {
                    drugaKartica = 31;
                } else if (drugaKartica == 42) {
                    drugaKartica = 41;
                } else if (drugaKartica == 52) {
                    drugaKartica = 51;
                } else if (drugaKartica == 62) {
                    drugaKartica = 61;
                } else if (drugaKartica == 72) {
                    drugaKartica = 71;
                } else if (drugaKartica == 82) {
                    drugaKartica = 81;
                } else if (drugaKartica == 92) {
                    drugaKartica = 91;
                } else if (drugaKartica == 102) {
                    drugaKartica = 101;
                } else if (drugaKartica == 112) {
                    drugaKartica = 111;
                } else if (drugaKartica == 122) {
                    drugaKartica = 121;
                } else if (drugaKartica == 132) {
                    drugaKartica = 131;
                } else if (drugaKartica == 142) {
                    drugaKartica = 141;
                } else if (drugaKartica == 152) {
                    drugaKartica = 151;
                } else if (drugaKartica == 162) {
                    drugaKartica = 161;
                } else if (drugaKartica == 172) {
                    drugaKartica = 171;
                } else if (drugaKartica == 182) {
                    drugaKartica = 181;
                }

                kliknutoDrugo = redniBr;
                brOkrenutihKarata = 1;
                karta1.setEnabled(false);
                karta2.setEnabled(false);
                karta3.setEnabled(false);
                karta4.setEnabled(false);
                karta5.setEnabled(false);
                karta6.setEnabled(false);
                karta7.setEnabled(false);
                karta8.setEnabled(false);
                karta9.setEnabled(false);
                karta10.setEnabled(false);
                karta11.setEnabled(false);
                karta12.setEnabled(false);
                karta13.setEnabled(false);
                karta14.setEnabled(false);
                karta15.setEnabled(false);
                karta16.setEnabled(false);
                karta17.setEnabled(false);
                karta18.setEnabled(false);
                karta19.setEnabled(false);
                karta20.setEnabled(false);
                karta21.setEnabled(false);
                karta22.setEnabled(false);
                karta23.setEnabled(false);
                karta24.setEnabled(false);
                karta25.setEnabled(false);
                karta26.setEnabled(false);
                karta27.setEnabled(false);
                karta28.setEnabled(false);
                karta29.setEnabled(false);
                karta30.setEnabled(false);
                karta31.setEnabled(false);
                karta32.setEnabled(false);
                karta33.setEnabled(false);
                karta34.setEnabled(false);
                karta35.setEnabled(false);
                karta36.setEnabled(false);

                Handler handler = new Handler();
                handler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        daLiSuIsteKarte3();
                    }
                }, 1000);
            }
        }
    }

    private void daLiSuIsteKarte1() {
        if (prvaKartica == drugaKartica) {
            if (kliknutoPrvo == 0) {
                karta1.setVisibility(View.INVISIBLE);
            } else if (kliknutoPrvo == 1) {
                karta2.setVisibility(View.INVISIBLE);
            }  else if (kliknutoPrvo == 2) {
                karta3.setVisibility(View.INVISIBLE);
            }  else if (kliknutoPrvo == 3) {
                karta4.setVisibility(View.INVISIBLE);
            }

            if (prvaKartica == drugaKartica) {
                if (kliknutoDrugo == 0) {
                    karta1.setVisibility(View.INVISIBLE);
                } else if (kliknutoDrugo == 1) {
                    karta2.setVisibility(View.INVISIBLE);
                } else if (kliknutoDrugo == 2) {
                    karta3.setVisibility(View.INVISIBLE);
                } else if (kliknutoDrugo == 3) {
                    karta4.setVisibility(View.INVISIBLE);
                }
            }

        } else {
            karta1.setImageResource(R.drawable.black_question_mark);
            karta2.setImageResource(R.drawable.black_question_mark);
            karta3.setImageResource(R.drawable.black_question_mark);
            karta4.setImageResource(R.drawable.black_question_mark);
        }

        karta1.setEnabled(true);
        karta2.setEnabled(true);
        karta3.setEnabled(true);
        karta4.setEnabled(true);

        daLiJeKrajIgre1();
    }

    private void daLiSuIsteKarte2() {
        if (prvaKartica == drugaKartica) {
            if (kliknutoPrvo == 0) {
                karta1.setVisibility(View.INVISIBLE);
            } else if (kliknutoPrvo == 1) {
                karta2.setVisibility(View.INVISIBLE);
            }  else if (kliknutoPrvo == 2) {
                karta3.setVisibility(View.INVISIBLE);
            }  else if (kliknutoPrvo == 3) {
                karta4.setVisibility(View.INVISIBLE);
            } else if (kliknutoPrvo == 4) {
                karta5.setVisibility(View.INVISIBLE);
            }  else if (kliknutoPrvo == 5) {
                karta6.setVisibility(View.INVISIBLE);
            }  else if (kliknutoPrvo == 6) {
                karta7.setVisibility(View.INVISIBLE);
            } else if (kliknutoPrvo == 7) {
                karta8.setVisibility(View.INVISIBLE);
            }  else if (kliknutoPrvo == 8) {
                karta9.setVisibility(View.INVISIBLE);
            }  else if (kliknutoPrvo == 9) {
                karta10.setVisibility(View.INVISIBLE);
            } else if (kliknutoPrvo == 10) {
                karta11.setVisibility(View.INVISIBLE);
            }  else if (kliknutoPrvo == 11) {
                karta12.setVisibility(View.INVISIBLE);
            }  else if (kliknutoPrvo == 12) {
                karta13.setVisibility(View.INVISIBLE);
            } else if (kliknutoPrvo == 13) {
                karta14.setVisibility(View.INVISIBLE);
            }  else if (kliknutoPrvo == 14) {
                karta15.setVisibility(View.INVISIBLE);
            }  else if (kliknutoPrvo == 15) {
                karta16.setVisibility(View.INVISIBLE);
            }

            if (prvaKartica == drugaKartica) {
                if (kliknutoDrugo == 0) {
                    karta1.setVisibility(View.INVISIBLE);
                } else if (kliknutoDrugo == 1) {
                    karta2.setVisibility(View.INVISIBLE);
                } else if (kliknutoDrugo == 2) {
                    karta3.setVisibility(View.INVISIBLE);
                } else if (kliknutoDrugo == 3) {
                    karta4.setVisibility(View.INVISIBLE);
                }  else if (kliknutoDrugo == 4) {
                    karta5.setVisibility(View.INVISIBLE);
                }  else if (kliknutoDrugo == 5) {
                    karta6.setVisibility(View.INVISIBLE);
                }  else if (kliknutoDrugo == 6) {
                    karta7.setVisibility(View.INVISIBLE);
                } else if (kliknutoDrugo == 7) {
                    karta8.setVisibility(View.INVISIBLE);
                }  else if (kliknutoDrugo == 8) {
                    karta9.setVisibility(View.INVISIBLE);
                }  else if (kliknutoDrugo == 9) {
                    karta10.setVisibility(View.INVISIBLE);
                } else if (kliknutoDrugo == 10) {
                    karta11.setVisibility(View.INVISIBLE);
                }  else if (kliknutoDrugo == 11) {
                    karta12.setVisibility(View.INVISIBLE);
                }  else if (kliknutoDrugo == 12) {
                    karta13.setVisibility(View.INVISIBLE);
                } else if (kliknutoDrugo == 13) {
                    karta14.setVisibility(View.INVISIBLE);
                }  else if (kliknutoDrugo == 14) {
                    karta15.setVisibility(View.INVISIBLE);
                }  else if (kliknutoDrugo == 15) {
                    karta16.setVisibility(View.INVISIBLE);
                }
            }

        } else {
            karta1.setImageResource(R.drawable.black_question_mark);
            karta2.setImageResource(R.drawable.black_question_mark);
            karta3.setImageResource(R.drawable.black_question_mark);
            karta4.setImageResource(R.drawable.black_question_mark);
            karta5.setImageResource(R.drawable.black_question_mark);
            karta6.setImageResource(R.drawable.black_question_mark);
            karta7.setImageResource(R.drawable.black_question_mark);
            karta8.setImageResource(R.drawable.black_question_mark);
            karta9.setImageResource(R.drawable.black_question_mark);
            karta10.setImageResource(R.drawable.black_question_mark);
            karta11.setImageResource(R.drawable.black_question_mark);
            karta12.setImageResource(R.drawable.black_question_mark);
            karta13.setImageResource(R.drawable.black_question_mark);
            karta14.setImageResource(R.drawable.black_question_mark);
            karta15.setImageResource(R.drawable.black_question_mark);
            karta16.setImageResource(R.drawable.black_question_mark);
        }

        karta1.setEnabled(true);
        karta2.setEnabled(true);
        karta3.setEnabled(true);
        karta4.setEnabled(true);
        karta5.setEnabled(true);
        karta6.setEnabled(true);
        karta7.setEnabled(true);
        karta8.setEnabled(true);
        karta9.setEnabled(true);
        karta10.setEnabled(true);
        karta11.setEnabled(true);
        karta12.setEnabled(true);
        karta13.setEnabled(true);
        karta14.setEnabled(true);
        karta15.setEnabled(true);
        karta16.setEnabled(true);

        daLiJeKrajIgre2();
    }

    private void daLiSuIsteKarte3() {
        if (prvaKartica == drugaKartica) {
            if (kliknutoPrvo == 0) {
                karta1.setVisibility(View.INVISIBLE);
            } else if (kliknutoPrvo == 1) {
                karta2.setVisibility(View.INVISIBLE);
            } else if (kliknutoPrvo == 2) {
                karta3.setVisibility(View.INVISIBLE);
            } else if (kliknutoPrvo == 3) {
                karta4.setVisibility(View.INVISIBLE);
            } else if (kliknutoPrvo == 4) {
                karta5.setVisibility(View.INVISIBLE);
            } else if (kliknutoPrvo == 5) {
                karta6.setVisibility(View.INVISIBLE);
            } else if (kliknutoPrvo == 6) {
                karta7.setVisibility(View.INVISIBLE);
            } else if (kliknutoPrvo == 7) {
                karta8.setVisibility(View.INVISIBLE);
            } else if (kliknutoPrvo == 8) {
                karta9.setVisibility(View.INVISIBLE);
            } else if (kliknutoPrvo == 9) {
                karta10.setVisibility(View.INVISIBLE);
            } else if (kliknutoPrvo == 10) {
                karta11.setVisibility(View.INVISIBLE);
            } else if (kliknutoPrvo == 11) {
                karta12.setVisibility(View.INVISIBLE);
            } else if (kliknutoPrvo == 12) {
                karta13.setVisibility(View.INVISIBLE);
            } else if (kliknutoPrvo == 13) {
                karta14.setVisibility(View.INVISIBLE);
            } else if (kliknutoPrvo == 14) {
                karta15.setVisibility(View.INVISIBLE);
            } else if (kliknutoPrvo == 15) {
                karta16.setVisibility(View.INVISIBLE);
            } else if (kliknutoPrvo == 16) {
                karta17.setVisibility(View.INVISIBLE);
            } else if (kliknutoPrvo == 17) {
                karta18.setVisibility(View.INVISIBLE);
            } else if (kliknutoPrvo == 18) {
                karta19.setVisibility(View.INVISIBLE);
            } else if (kliknutoPrvo == 19) {
                karta20.setVisibility(View.INVISIBLE);
            } else if (kliknutoPrvo == 20) {
                karta21.setVisibility(View.INVISIBLE);
            } else if (kliknutoPrvo == 21) {
                karta22.setVisibility(View.INVISIBLE);
            } else if (kliknutoPrvo == 22) {
                karta23.setVisibility(View.INVISIBLE);
            } else if (kliknutoPrvo == 23) {
                karta24.setVisibility(View.INVISIBLE);
            } else if (kliknutoPrvo == 24) {
                karta25.setVisibility(View.INVISIBLE);
            } else if (kliknutoPrvo == 25) {
                karta26.setVisibility(View.INVISIBLE);
            } else if (kliknutoPrvo == 26) {
                karta27.setVisibility(View.INVISIBLE);
            } else if (kliknutoPrvo == 27) {
                karta28.setVisibility(View.INVISIBLE);
            } else if (kliknutoPrvo == 28) {
                karta29.setVisibility(View.INVISIBLE);
            } else if (kliknutoPrvo == 29) {
                karta30.setVisibility(View.INVISIBLE);
            } else if (kliknutoPrvo == 30) {
                karta31.setVisibility(View.INVISIBLE);
            } else if (kliknutoPrvo == 31) {
                karta32.setVisibility(View.INVISIBLE);
            } else if (kliknutoPrvo == 32) {
                karta33.setVisibility(View.INVISIBLE);
            } else if (kliknutoPrvo == 33) {
                karta34.setVisibility(View.INVISIBLE);
            } else if (kliknutoPrvo == 34) {
                karta35.setVisibility(View.INVISIBLE);
            } else if (kliknutoPrvo == 35) {
                karta36.setVisibility(View.INVISIBLE);
            }

            if (prvaKartica == drugaKartica) {
                if (kliknutoDrugo == 0) {
                    karta1.setVisibility(View.INVISIBLE);
                } else if (kliknutoDrugo == 1) {
                    karta2.setVisibility(View.INVISIBLE);
                } else if (kliknutoDrugo == 2) {
                    karta3.setVisibility(View.INVISIBLE);
                } else if (kliknutoDrugo == 3) {
                    karta4.setVisibility(View.INVISIBLE);
                } else if (kliknutoDrugo == 4) {
                    karta5.setVisibility(View.INVISIBLE);
                } else if (kliknutoDrugo == 5) {
                    karta6.setVisibility(View.INVISIBLE);
                } else if (kliknutoDrugo == 6) {
                    karta7.setVisibility(View.INVISIBLE);
                } else if (kliknutoDrugo == 7) {
                    karta8.setVisibility(View.INVISIBLE);
                } else if (kliknutoDrugo == 8) {
                    karta9.setVisibility(View.INVISIBLE);
                } else if (kliknutoDrugo == 9) {
                    karta10.setVisibility(View.INVISIBLE);
                } else if (kliknutoDrugo == 10) {
                    karta11.setVisibility(View.INVISIBLE);
                } else if (kliknutoDrugo == 11) {
                    karta12.setVisibility(View.INVISIBLE);
                } else if (kliknutoDrugo == 12) {
                    karta13.setVisibility(View.INVISIBLE);
                } else if (kliknutoDrugo == 13) {
                    karta14.setVisibility(View.INVISIBLE);
                } else if (kliknutoDrugo == 14) {
                    karta15.setVisibility(View.INVISIBLE);
                } else if (kliknutoDrugo == 15) {
                    karta16.setVisibility(View.INVISIBLE);
                } else if (kliknutoDrugo == 16) {
                    karta17.setVisibility(View.INVISIBLE);
                } else if (kliknutoDrugo == 17) {
                    karta18.setVisibility(View.INVISIBLE);
                } else if (kliknutoDrugo == 18) {
                    karta19.setVisibility(View.INVISIBLE);
                } else if (kliknutoDrugo == 19) {
                    karta20.setVisibility(View.INVISIBLE);
                } else if (kliknutoDrugo == 20) {
                    karta21.setVisibility(View.INVISIBLE);
                } else if (kliknutoDrugo == 21) {
                    karta22.setVisibility(View.INVISIBLE);
                } else if (kliknutoDrugo == 22) {
                    karta23.setVisibility(View.INVISIBLE);
                } else if (kliknutoDrugo == 23) {
                    karta24.setVisibility(View.INVISIBLE);
                } else if (kliknutoDrugo == 24) {
                    karta25.setVisibility(View.INVISIBLE);
                } else if (kliknutoDrugo == 25) {
                    karta26.setVisibility(View.INVISIBLE);
                } else if (kliknutoDrugo == 26) {
                    karta27.setVisibility(View.INVISIBLE);
                } else if (kliknutoDrugo == 27) {
                    karta28.setVisibility(View.INVISIBLE);
                } else if (kliknutoDrugo == 28) {
                    karta29.setVisibility(View.INVISIBLE);
                } else if (kliknutoDrugo == 29) {
                    karta30.setVisibility(View.INVISIBLE);
                } else if (kliknutoDrugo == 30) {
                    karta31.setVisibility(View.INVISIBLE);
                } else if (kliknutoDrugo == 31) {
                    karta32.setVisibility(View.INVISIBLE);
                } else if (kliknutoDrugo == 32) {
                    karta33.setVisibility(View.INVISIBLE);
                } else if (kliknutoDrugo == 33) {
                    karta34.setVisibility(View.INVISIBLE);
                } else if (kliknutoDrugo == 34) {
                    karta35.setVisibility(View.INVISIBLE);
                } else if (kliknutoDrugo == 35) {
                    karta36.setVisibility(View.INVISIBLE);
                }
            }

        } else {
            karta1.setImageResource(R.drawable.black_question_mark);
            karta2.setImageResource(R.drawable.black_question_mark);
            karta3.setImageResource(R.drawable.black_question_mark);
            karta4.setImageResource(R.drawable.black_question_mark);
            karta5.setImageResource(R.drawable.black_question_mark);
            karta6.setImageResource(R.drawable.black_question_mark);
            karta7.setImageResource(R.drawable.black_question_mark);
            karta8.setImageResource(R.drawable.black_question_mark);
            karta9.setImageResource(R.drawable.black_question_mark);
            karta10.setImageResource(R.drawable.black_question_mark);
            karta11.setImageResource(R.drawable.black_question_mark);
            karta12.setImageResource(R.drawable.black_question_mark);
            karta13.setImageResource(R.drawable.black_question_mark);
            karta14.setImageResource(R.drawable.black_question_mark);
            karta15.setImageResource(R.drawable.black_question_mark);
            karta16.setImageResource(R.drawable.black_question_mark);
            karta17.setImageResource(R.drawable.black_question_mark);
            karta18.setImageResource(R.drawable.black_question_mark);
            karta19.setImageResource(R.drawable.black_question_mark);
            karta20.setImageResource(R.drawable.black_question_mark);
            karta21.setImageResource(R.drawable.black_question_mark);
            karta22.setImageResource(R.drawable.black_question_mark);
            karta23.setImageResource(R.drawable.black_question_mark);
            karta24.setImageResource(R.drawable.black_question_mark);
            karta25.setImageResource(R.drawable.black_question_mark);
            karta26.setImageResource(R.drawable.black_question_mark);
            karta27.setImageResource(R.drawable.black_question_mark);
            karta28.setImageResource(R.drawable.black_question_mark);
            karta29.setImageResource(R.drawable.black_question_mark);
            karta30.setImageResource(R.drawable.black_question_mark);
            karta31.setImageResource(R.drawable.black_question_mark);
            karta32.setImageResource(R.drawable.black_question_mark);
            karta33.setImageResource(R.drawable.black_question_mark);
            karta34.setImageResource(R.drawable.black_question_mark);
            karta35.setImageResource(R.drawable.black_question_mark);
            karta36.setImageResource(R.drawable.black_question_mark);
        }

        karta1.setEnabled(true);
        karta2.setEnabled(true);
        karta3.setEnabled(true);
        karta4.setEnabled(true);
        karta5.setEnabled(true);
        karta6.setEnabled(true);
        karta7.setEnabled(true);
        karta8.setEnabled(true);
        karta9.setEnabled(true);
        karta10.setEnabled(true);
        karta11.setEnabled(true);
        karta12.setEnabled(true);
        karta13.setEnabled(true);
        karta14.setEnabled(true);
        karta15.setEnabled(true);
        karta16.setEnabled(true);
        karta17.setEnabled(true);
        karta18.setEnabled(true);
        karta19.setEnabled(true);
        karta20.setEnabled(true);
        karta21.setEnabled(true);
        karta22.setEnabled(true);
        karta23.setEnabled(true);
        karta24.setEnabled(true);
        karta25.setEnabled(true);
        karta26.setEnabled(true);
        karta27.setEnabled(true);
        karta28.setEnabled(true);
        karta29.setEnabled(true);
        karta30.setEnabled(true);
        karta31.setEnabled(true);
        karta32.setEnabled(true);
        karta33.setEnabled(true);
        karta34.setEnabled(true);
        karta35.setEnabled(true);
        karta36.setEnabled(true);

        daLiJeKrajIgre3();
    }

    private void daLiJeKrajIgre1() {
        if (karta1.getVisibility() == View.INVISIBLE && karta2.getVisibility() == View.INVISIBLE &&
                karta3.getVisibility() == View.INVISIBLE && karta4.getVisibility() == View.INVISIBLE) {
            izmeneUbazi();
        }
    }

    private void daLiJeKrajIgre2() {
        if (karta1.getVisibility() == View.INVISIBLE && karta2.getVisibility() == View.INVISIBLE &&
                karta3.getVisibility() == View.INVISIBLE && karta4.getVisibility() == View.INVISIBLE  && karta5.getVisibility() == View.INVISIBLE &&
                karta6.getVisibility() == View.INVISIBLE && karta7.getVisibility() == View.INVISIBLE  && karta8.getVisibility() == View.INVISIBLE &&
                karta9.getVisibility() == View.INVISIBLE && karta10.getVisibility() == View.INVISIBLE  && karta11.getVisibility() == View.INVISIBLE &&
                karta12.getVisibility() == View.INVISIBLE && karta13.getVisibility() == View.INVISIBLE  && karta14.getVisibility() == View.INVISIBLE &&
                karta15.getVisibility() == View.INVISIBLE && karta16.getVisibility() == View.INVISIBLE ) {
            izmeneUbazi();
        }
    }

    private void daLiJeKrajIgre3() {
        if (karta1.getVisibility() == View.INVISIBLE && karta2.getVisibility() == View.INVISIBLE &&
                karta3.getVisibility() == View.INVISIBLE && karta4.getVisibility() == View.INVISIBLE  && karta5.getVisibility() == View.INVISIBLE &&
                karta6.getVisibility() == View.INVISIBLE && karta7.getVisibility() == View.INVISIBLE  && karta8.getVisibility() == View.INVISIBLE &&
                karta9.getVisibility() == View.INVISIBLE && karta10.getVisibility() == View.INVISIBLE  && karta11.getVisibility() == View.INVISIBLE &&
                karta12.getVisibility() == View.INVISIBLE && karta13.getVisibility() == View.INVISIBLE  && karta14.getVisibility() == View.INVISIBLE &&
                karta15.getVisibility() == View.INVISIBLE && karta16.getVisibility() == View.INVISIBLE && karta17.getVisibility() == View.INVISIBLE &&
                karta18.getVisibility() == View.INVISIBLE && karta19.getVisibility() == View.INVISIBLE && karta20.getVisibility() == View.INVISIBLE  &&
                karta21.getVisibility() == View.INVISIBLE && karta22.getVisibility() == View.INVISIBLE && karta23.getVisibility() == View.INVISIBLE  &&
                karta24.getVisibility() == View.INVISIBLE && karta25.getVisibility() == View.INVISIBLE && karta26.getVisibility() == View.INVISIBLE  &&
                karta27.getVisibility() == View.INVISIBLE && karta28.getVisibility() == View.INVISIBLE && karta29.getVisibility() == View.INVISIBLE  &&
                karta30.getVisibility() == View.INVISIBLE && karta31.getVisibility() == View.INVISIBLE && karta32.getVisibility() == View.INVISIBLE &&
                karta33.getVisibility() == View.INVISIBLE && karta34.getVisibility() == View.INVISIBLE && karta35.getVisibility() == View.INVISIBLE &&
                karta36.getVisibility() == View.INVISIBLE) {
            izmeneUbazi();
            krajIgrice();
        }
    }

    public void izmeneUbazi() {
        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            nivo = extras.getString("nivo");
            nivoInt = Integer.parseInt(nivo);
            ime = extras.getString("ime");
        }

        baza = new DB(this);
        baza.promeniNivo(ime);

        Intent intent = new Intent(this, LvlCompleted.class);
        intent.putExtra("ime", ime);
        nivo = ((Integer)(nivoInt + 1)).toString();
        intent.putExtra("nivo", nivo);
        startActivity(intent);
    }

    public void krajIgrice() {
        Intent intent = new Intent(this, KrajIgre.class);
        startActivity(intent);
    }

    public void idiNaPocetak(View view) {
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }
}

package com.example.memory;

public class Igrac {
    String ime;
    int nivo;
    int poeni;

    public Igrac(String ime, int nivo, int poeni) {
        super();
        this.ime = ime;
        this.nivo = nivo;
        this.poeni = poeni;
    }

    public String getIme() {
        return ime;
    }

    public String getNivo() {
        return ((Integer)nivo).toString();
    }

    public String getPoeni() {
        return ((Integer)poeni).toString();
    }
}

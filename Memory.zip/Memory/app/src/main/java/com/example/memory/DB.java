package com.example.memory;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.DatabaseUtils;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DB extends SQLiteOpenHelper {
    private static final String nazivBaze = "baza.db";
    private static final String nazivTabele = "igraci";

    public DB(Context context) {
        super(context, nazivBaze, null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String kreiraj = "CREATE TABLE " +  nazivTabele + " (ime VARCHAR(25) PRIMARY KEY, nivo INTEGER, poeni INTEGER);";
        db.execSQL(kreiraj);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        String odbaci = "DROP TABLE IF EXISTS " + nazivTabele;
        db.execSQL(odbaci);

        onCreate(db);
    }

    public boolean dodajIgraca(String ime, int nivo, int poeni) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues contentValues = new ContentValues();
        contentValues.put("ime", ime);
        contentValues.put("nivo", nivo);
        contentValues.put("poeni", poeni);

        long rezultat = db.insert(nazivTabele, null, contentValues);

        if (rezultat == -1) {
            return false;
        } else {
            return true;
        }
    }

    public Cursor sadrzaj() {
        SQLiteDatabase db = this.getWritableDatabase();

        String upit = "SELECT * FROM " + nazivTabele;
        Cursor kursor = db.rawQuery(upit, null);
        return kursor;
    }

    public void promeniNivo(String ime) {
        SQLiteDatabase db = this.getWritableDatabase();

       String nivo = DatabaseUtils.stringForQuery(db,
                    "SELECT nivo FROM "+nazivTabele+" WHERE ime = ?",
                    new String[]{ ime });

        int nivoInt = Integer.parseInt(nivo);

        ContentValues contentValues = new ContentValues();
        contentValues.put("nivo", nivoInt + 1);
        db.update(nazivTabele, contentValues, "ime = ?", new String[] {ime});
    }

    public void povecajPoene(String ime) {
        SQLiteDatabase db = this.getWritableDatabase();

        String poeni = DatabaseUtils.stringForQuery(db,
                "SELECT poeni FROM "+nazivTabele+" WHERE ime = ?",
                new String[]{ ime });

        int poeniInt = Integer.parseInt(poeni);

        ContentValues contentValues = new ContentValues();
        contentValues.put("poeni", poeniInt + 100);
        db.update(nazivTabele, contentValues, "ime = ?", new String[] {ime});
    }
}

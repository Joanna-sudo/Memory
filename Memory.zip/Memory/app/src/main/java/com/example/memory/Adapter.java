package com.example.memory;

import android.app.Activity;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;
import java.util.List;

public class Adapter extends ArrayAdapter<Igrac> {

    public Adapter (Activity context, List<Igrac> igraci) {
        super(context, 0, igraci);
    }

    @Override
    public View getView (int pozicija, View promeniView, ViewGroup viewGroup) {
        Igrac igrac = getItem(pozicija);

        if (promeniView == null) {
            promeniView = LayoutInflater.from(getContext()).inflate(R.layout.list_item, viewGroup, false);
        }

        TextView textView1 = (TextView) promeniView.findViewById(R.id.textView3);
        textView1.setText(igrac.getIme());
        textView1.setPadding(2, 0, 0, 0);

        TextView textView2 = (TextView) promeniView.findViewById(R.id.textView4);
        textView2.setText(igrac.getNivo());
        textView1.setGravity(Gravity.CENTER);

        TextView textView3 = (TextView) promeniView.findViewById(R.id.textView5);
        textView3.setText(igrac.getPoeni());
        textView3.setPadding(0, 0, 0, 10);
        textView3.setGravity(Gravity.CENTER);

        return promeniView;
    }

}

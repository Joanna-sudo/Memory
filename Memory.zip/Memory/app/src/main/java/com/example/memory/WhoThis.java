package com.example.memory;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;

public class WhoThis extends AppCompatActivity {
    DB baza;
    ListView listView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.who_this);

        baza = new DB(this);
        listView = findViewById(R.id.list);
        popuniListu();

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                int i = 0;

                Cursor kursor = baza.sadrzaj();
                kursor.moveToLast();
                //position krece od nule :)
                while (i != position) {
                    kursor.moveToPrevious();
                    i++;
                }

                String nivo = ((Integer)kursor.getInt(1)).toString();
                String ime = kursor.getString(0);

                if (nivo.equals("4")) {
                    String str = getString(R.string.mess2);
                    Toast.makeText(WhoThis.this, str, Toast.LENGTH_LONG).show();
                } else {
                    Intent intent = new Intent(view.getContext(), Game.class);
                    intent.putExtra("nivo", nivo);
                    intent.putExtra("ime", ime);
                    startActivity(intent);
                }
            }
        });
    }

    public void popuniListu() {
        Cursor kursor = baza.sadrzaj();
        kursor.moveToLast();
        ArrayList<Igrac> lista = new ArrayList<>();
        Igrac igrac;
        igrac = new Igrac(kursor.getString(0), kursor.getInt(1), kursor.getInt(2));
        lista.add(igrac);
        while (kursor.moveToPrevious()) {
            igrac = new Igrac(kursor.getString(0), kursor.getInt(1), kursor.getInt(2));
            lista.add(igrac);
        }

        Adapter adapter = new Adapter(this, lista);
        listView.setAdapter(adapter);
    }

}
